#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @project: ${PROJECT_NAME}
*
* @description: ${description}
*
* @author: DingHaoLun
*
* @create: ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
**/
public class ${NAME} {
}